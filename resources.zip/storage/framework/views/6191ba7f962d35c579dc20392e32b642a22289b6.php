<?php $__env->startSection('color&sizeactive'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Covid-color&size
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
        <nav class="breadcrumb sl-breadcrumb">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>">Dashboard</a>
            <span class="breadcrumb-item active">Color & Size</span>
        </nav>

        <div class="sl-pagebody">
            <section>
                <div class="">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-header"
                                    style="text-transform: uppercase; letter-spacing: 2px; background-color: tomato; color: white;">
                                    <div class="card-title">
                                        <h1
                                            style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                            Subcategory Information</h1>
                                    </div>
                                </div>
                                <?php if(session('delete')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('delete')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Sl</th>
                                                <th scope="col">Color Name</th>
                                                <th scope="col">Color Id</th>
                                                <th scope="col">Created At</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                                    <td><?php echo e($color->color_name); ?></td>
                                                    <td>
                                                        <?php echo e($color->id); ?>

                                                        
                                                    </td>
                                                    <td><?php echo e($color->created_at); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('/subcategory/edit')); ?>/<?php echo e($color->id); ?>"
                                                            class="btn btn-warning">Edit</a>
                                                        <a href="<?php echo e(url('/subcategory/delete')); ?>/<?php echo e($color->id); ?>"
                                                            style="background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color:white"
                                                            class="btn">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4" style="margin-bottom: 20px">
                            <div class="card">
                                <div class="card-header"
                                    style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                    <div class="card-title">
                                        <h2
                                            style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                            Add Color</h2>
                                    </div>
                                </div>
                                <?php if(session('insert_color')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('insert_color')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('subnameexist')): ?>
                                    <div class="alert alert-warning">
                                        <?php echo e(session('subnameexist')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <form action="<?php echo e(route('color_size_insert')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="form-label" for="">Color Name</label>
                                            <input type="text" name="color_name" class="form-control">
                                            <?php $__errorArgs = ['color_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-warning">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label" for="">Color Code</label>
                                            <input type="text" name="color_code" class="form-control">
                                            <?php $__errorArgs = ['color_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-warning">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group text-center mt-3">
                                            <button
                                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;"
                                                class="btn text-center" type="submit">Add Color</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-header"
                                    style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                    <div class="card-title">
                                        <h1
                                            style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                            Size Information</h1>
                                    </div>
                                </div>
                                <?php if(session('delete')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('delete')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">Sl</th>
                                                <th scope="col">Size Name</th>
                                                <th scope="col">Size Id</th>
                                                <th scope="col">Created At</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                                    <td><?php echo e($size->size_name); ?></td>
                                                    <td><?php echo e($size->id); ?></td>
                                                    <td><?php echo e($size->created_at); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('/subcategory/edit')); ?>/<?php echo e($size->id); ?>"
                                                            class="btn btn-warning">Edit</a>
                                                        <a href="<?php echo e(url('/subcategory/delete')); ?>/<?php echo e($size->id); ?>"
                                                            style="background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color:white"
                                                            class="btn">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header"
                                    style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                    <div class="card-title">
                                        <h2
                                            style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                            Add Size</h2>
                                    </div>
                                </div>
                                <?php if(session('insert_size')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('insert_size')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('subnameexist')): ?>
                                    <div class="alert alert-warning">
                                        <?php echo e(session('subnameexist')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <form action="<?php echo e(route('size_insert')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="form-label" for="">Size Name</label>
                                            <input type="text" name="size_name" class="form-control">
                                            <?php $__errorArgs = ['size_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-warning">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group text-center mt-3">
                                            <button
                                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;"
                                                class="btn text-center" type="submit">Add size</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\color_size\index.blade.php ENDPATH**/ ?>