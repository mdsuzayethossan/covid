<?php $__env->startSection('navigationactive'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Navigationbar
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\navigationbar\index.blade.php ENDPATH**/ ?>