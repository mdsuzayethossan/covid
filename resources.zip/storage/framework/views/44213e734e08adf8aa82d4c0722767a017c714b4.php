;
<?php $__env->startSection('couponactive'); ?>
active

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Coupon
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
        <nav class="breadcrumb sl-breadcrumb">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>">Dashboard</a>
            <span class="breadcrumb-item active">Coupon</span>
        </nav>

        <div class="sl-pagebody">
            <div class="">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="card">
                            <div class="card-header"
                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                <div class="card-title">
                                    <h1
                                        style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Category Information</h1>
                                </div>
                            </div>

                            <?php if(session('delete')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('delete')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sl</th>
                                            <th scope="col">Coupon Name</th>
                                            <th scope="col">Validity</th>
                                            <th scope="col"> Discount</th>
                                            <th scope="col">Created At</th>
                                            <th scope="col">Updated At</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <thead>
                                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                                <td><?php echo e($coupon->coupon_name); ?></td>
                                                <td><?php echo e($coupon->validity); ?>

                                                </td>
                                                <td><?php echo e($coupon->discount); ?></td>
                                                <td><?php echo e($coupon->created_at->diffforHumans()); ?></td>
                                                <td><?php echo e($coupon->updated_at); ?></td>
                                                <td>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </thead>
                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-5">
                        <div class="card custom_card">
                            <div class="card-header"
                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                <div class="card-title">
                                    <h1
                                        style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Coupon</h1>
                                </div>

                            </div>
                            <?php if(session('coupon_added')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('coupon_added')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <form action="<?php echo e(route('coupon_insert')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="" class="form-label">Coupon Name</label>
                                        <input type="text" class="form-control" name="coupon_name">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Coupon Validity</label>
                                        <input type="date" class="form-control" name="validity">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Coupon discount percentage</label>
                                        <input type="number" class="form-control" name="discount">
                                        
                                    </div>
                                    <div class="form-group text-center mt-3">
                                        <button
                                            style="text-transform: uppercase; letter-spacing: 2px;background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;"
                                            class="btn text-center" type="submit">Add Coupon</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\coupon\coupon.blade.php ENDPATH**/ ?>