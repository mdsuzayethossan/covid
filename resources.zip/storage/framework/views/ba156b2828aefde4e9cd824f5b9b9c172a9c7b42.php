<?php $__env->startSection('categoryactive'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Covid-Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
        <nav class="breadcrumb sl-breadcrumb">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>">Dashboard</a>
            <span class="breadcrumb-item active">Category</span>
        </nav>

        <div class="sl-pagebody">
            <div class="">
                <div class="row" style="margin-bottom: 50px;">
                    <div class="col-lg-4 m-auto">
                        <div class="card custom_card">
                            <div class="card-header"
                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                <div class="card-title">
                                    <h1
                                        style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Add Category</h1>
                                </div>

                            </div>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <form action="<?php echo e(route('category_insert')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="" class="form-label">Category Name</label>
                                        <input type="text" class="form-control" name="category_name">
                                        <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger"><?php echo e($message); ?></strong>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group text-center mt-3">
                                        <button
                                            style="text-transform: uppercase; letter-spacing: 2px;background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;"
                                            class="btn text-center" type="submit">Add Category</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-10 m-auto">
                        <div class="card">
                            <div class="card-header"
                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                <div class="card-title">
                                    <h1
                                        style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Category Information</h1>
                                </div>
                            </div>

                            <?php if(session('delete')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('delete')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sl</th>
                                            <th scope="col">Category Name</th>
                                            <th scope="col">Added By</th>
                                            <th scope="col"> Image</th>
                                            <th scope="col">Created At</th>
                                            <th scope="col">Updated At</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <thead>
                                        <?php $__currentLoopData = $catemaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                                <td><?php echo e($category->category_name); ?></td>
                                                <td><?php echo e(App\Models\User::where('id', $category->added_by)->first()->name); ?>

                                                </td>
                                                <td><img width="70"
                                                        src="<?php echo e(asset('uploads/category/')); ?>/<?php echo e($category->category_image); ?>"
                                                        alt=""></td>
                                                <td><?php echo e($category->created_at->diffforHumans()); ?></td>
                                                <td><?php echo e($category->updated_at->diffforHumans()); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('/category/edit')); ?>/<?php echo e($category->id); ?>"
                                                        class="btn btn-secondary">Edit</a>
                                                    <a href="<?php echo e(url('/category/delete')); ?>/<?php echo e($category->id); ?>"
                                                        class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </thead>
                                </table>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-10 m-auto">
                        <div class="card">
                            <div class="card-header"
                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fb5d5d 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                <div class="card-title">
                                    <h1
                                        style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Trashed Category Information</h1>
                                </div>
                            </div>
                            <?php if(session('cate_success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('cate_success')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sl</th>
                                            <th scope="col">Category Name</th>
                                            <th scope="col">Added By</th>
                                            <th scope="col"> Image</th>
                                            <th scope="col">Created At</th>
                                            <th scope="col">Updated At</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <thead>
                                        <?php $__currentLoopData = $trashed_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trashed_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                                <td><?php echo e($trashed_category->category_name); ?></td>
                                                <td><?php echo e(App\Models\User::where('id', $trashed_category->added_by)->first()->name); ?>

                                                </td>
                                                <td><img width="70"
                                                        src="<?php echo e(asset('uploads/category/')); ?>/<?php echo e($trashed_category->category_image); ?>"
                                                        alt=""></td>
                                                <td><?php echo e($trashed_category->created_at->diffforHumans()); ?></td>
                                                <td><?php echo e($trashed_category->updated_at->diffforHumans()); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('/category/edit')); ?>/<?php echo e($trashed_category->id); ?>"
                                                        class="btn btn-secondary">Edit</a>
                                                    <a href="<?php echo e(url('/category/restore')); ?>/<?php echo e($trashed_category->id); ?>"
                                                        class="btn btn-danger">Restore</a>
                                                    <a href="<?php echo e(url('/category/forcedelete')); ?>/<?php echo e($trashed_category->id); ?>"
                                                        class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script>
    <?php if(session('category_force_delete')): ?>
    const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })

  Toast.fire({
    icon: 'success',
    title: '<?php echo e(session('category_force_delete')); ?>'
  });


<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\category\index.blade.php ENDPATH**/ ?>