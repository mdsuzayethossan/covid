;
<?php $__env->startSection('content'); ?>
<!-- ########## START: MAIN PANEL ########## -->
<div class="sl-mainpanel">
    <nav class="breadcrumb sl-breadcrumb">
      <a class="breadcrumb-item" href="index.html">Starlight</a>
      <a class="breadcrumb-item" href="index.html">Pages</a>
      <span class="breadcrumb-item active">Blank Page</span>
    </nav>

    <div class="sl-pagebody">
        <div class="row">
            <div class="col-lg-5 m-auto">
                <div class="card">
                    <div class="card-header" style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;">
                        <div class="card-title">
                            <h1 style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                Profile Edit</h1>
                        </div>


                    </div>
                    <?php if(session('update_pass')): ?>
                        <div class="alert alert-warning">
                            <?php echo e(session('update_pass')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error_update_pass')): ?>

                    <div class="alert alert-warning">
                        <?php echo e(session('error_update_pass')); ?>

                    </div>

                    <?php endif; ?>
                    <div class="card-body">
                        <form action="<?php echo e(url('/profile/update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="" class="form-label">
                                    Change Name
                                </label>
                                <input type="text" class="form-control" name="profile_name" value="<?php echo e(Auth::user()->name); ?>">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="ol_password" placeholder="Type Old Password">

                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder="Type New Password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-warning">
                                        <?php echo e($message); ?>

                                    </div>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password">
                            </div>
                            <div class="form-group">
                                <label for="" class="form-label">Photo</label>
                                <input type="file" class="form-control" name="photo">
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-warning">
                                        <?php echo e($message); ?>

                                    </div>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group text-center mt-3">
                                <button style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;" class="btn text-center" type="submit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- sl-pagebody -->
  </div><!-- sl-mainpanel -->
  <!-- ########## END: MAIN PANEL ########## -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\profile\edit.blade.php ENDPATH**/ ?>