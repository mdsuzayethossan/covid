<h1>Ami product Edit</h1>
<?php /**PATH F:\laravel\covid\resources\views\admin\product\edit.blade.php ENDPATH**/ ?>