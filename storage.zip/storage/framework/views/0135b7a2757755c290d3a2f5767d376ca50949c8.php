<?php $__env->startSection('dahboardactive'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Covid-user
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
        <nav class="breadcrumb sl-breadcrumb">
            <span class="breadcrumb-item active">Dashboard</span>
        </nav>

        <div class="sl-pagebody">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title" style="text-transform: uppercase;">
                                    <h2>Welcome, <?php echo e($logged_user); ?> <span class="float-end"> Total User:
                                            <?php echo e($total_user); ?></span></h2>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sl</th>
                                            <th scope="col">Name</th>

                                            <th scope="col">Email</th>
                                            <th scope="col">Role</th>
                                            <th scope="col">Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($all_users->firstitem() + $key); ?></th>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td>
                                                    <?php
                                                        if ($user->role == 1) {
                                                            echo 'Author';
                                                        } elseif ($user->role == 2) {
                                                            echo 'Admin';
                                                        } elseif ($user->role == 3) {
                                                            echo 'Moderator';
                                                        } elseif ($user->role == 4) {
                                                            echo 'Editor';
                                                        } elseif ($user->role == 5) {
                                                            echo 'Subscriber';
                                                        } else {
                                                            echo 'Viewer';
                                                        }
                                                    ?>
                                                </td>
                                                <td><?php echo e($user->created_at->diffInHours() > 24? $user->created_at->format('d-m-y h:i:s A'): $user->created_at->diffForHumans()); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php echo e($all_users->links()); ?>


                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header"
                                style="text-transform: uppercase; letter-spacing: 2px; background: linear-gradient(-155deg, #fd3d6b 0, #fd7863 98%, #f3dfe0 100%); color: white;">
                                <div class="card-title">
                                    <h1
                                        style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Add User</h1>

                                </div>
                            </div>
                            <?php if(session('add_role')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('add_role')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <form action="<?php echo e(url('/add/role')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="" class="form-label">Name</label>
                                        <input type="text" class="form-control" name="name">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Email Address</label>
                                        <input type="email" class="form-control" name="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Password</label>
                                        <input type="password" class="form-control" name="password">
                                    </div>
                                    <div class="form-group">
                                        <select name="role" id="" class="form-control">
                                            <option value="">--Select Role--</option>
                                            <option value="1">Owner</option>
                                            <option value="2">Admin</option>
                                            <option value="3">Moderator</option>
                                            <option value="4">Editor</option>
                                            <option value="5">Subscriber</option>
                                            <option value="6">Viewer</option>

                                        </select>
                                    </div>
                                    <div class="form-group text-center mt-3">
                                        <button
                                            style="text-transform: uppercase;     background: linear-gradient(-155deg, #fd3d6b 0, #fd7863 98%, #f3dfe0 100%); letter-spacing: 2px; color: white;"
                                            class="btn text-center" type="submit">Add User</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\home.blade.php ENDPATH**/ ?>