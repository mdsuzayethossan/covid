<?php $__env->startSection('content'); ?>
    <div class="sl-mainpanel">
        <nav class="breadcrumb sl-breadcrumb">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>">Dashboard</a>
            <span class="breadcrumb-item active">Inventory</span>
        </nav>

        <div class="sl-pagebody">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header"
                            style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;">
                            <div class="card-title">
                                <h2
                                    style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                    Products Information</h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Sl</th>
                                        <th scope="col">Pro_Id</th>
                                        <th scope="col">Pro_Name</th>
                                        <th scope="col">color</th>
                                        <th scope="col">Co_Id</th>
                                        <th scope="col">Size</th>
                                        <th scope="col">Si_Id</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pro_inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro_inventories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key + 1); ?></th>
                                            <td><?php echo e($pro_inventories->product_id); ?></td>
                                            <td><?php echo e(App\Models\Product::find($pro_inventories->product_id)->product_name); ?>

                                            </td>
                                            <td><?php echo e(App\Models\color::find($pro_inventories->color_id)->color_name); ?></td>
                                            <td> <?php echo e($pro_inventories->size_id); ?></td>
                                            <td><?php echo e(App\Models\size::find($pro_inventories->size_id)->size_name); ?></td>
                                            <td><?php echo e($pro_inventories->size_id); ?></td>
                                            <td><?php echo e($pro_inventories->product_quantity); ?></td>
                                            <td><img src="<?php echo e(asset('')); ?>" alt=""></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header"
                            style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;">
                            <div class="card-title">
                                <h2
                                    style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                    Add Inventory</h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(url('/inventory/insert')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="" class="form-label">
                                        Product Name
                                    </label>
                                    <input type="text" readonly name="product_name"
                                        value="<?php echo e($product_info->product_name); ?>" class="form-control">
                                    <input type="hidden" name="product_id" value="<?php echo e($product_info->id); ?>"
                                        class="form-control">
                                </div>
                                <div class="form-group">
                                    <select name="color_id" id="" class="form-control">
                                        <option value="">--Select Color--</option>
                                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($color->id); ?>"><?php echo e($color->color_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </select>
                                </div>
                                <div class="form-group">
                                    <select name="size_id" id="" class="form-control">
                                        <option value="">--Select Size--</option>
                                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($size->id); ?>"><?php echo e($size->size_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="" class="form-label">Product Quantity</label>
                                    <input type="text" name="product_quantity" class="form-control">
                                </div>
                                <div class="form-group text-center mt-3">
                                    <button
                                        style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;"
                                        class="btn text-center" type="submit">Add Inventory</button>
                                </div>


                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\product\inventory\inventory.blade.php ENDPATH**/ ?>