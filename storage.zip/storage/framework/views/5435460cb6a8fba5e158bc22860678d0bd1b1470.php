<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6 m-auto">
            <div class="card">
                <div class="card-header">
                    <div class="card-title text-center">
                        <img src="<?php echo e(asset('frontend_assets/images/logo/logo.png')); ?>" alt="">

                    </div>
                </div>
                <div class="card-body text-center">
                    <h2>Hi!, <?php if(session('customer_name')): ?>
                        <?php echo e(session('customer_name')); ?>


                    <?php endif; ?></h2>
                    <h3 class="text-center">congratulations! </h3>
                    <h5 class="text-center">
                        <?php if(session('verified')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('verified')); ?>

                          </div>

                        <?php endif; ?>
                    </h5>

                    <a href="<?php echo e(route('customer_register')); ?>" style="width: 135px; height: 33px; text-align:center; display:inline-block;   line-height: 33px;" class="shop-link btn btn-primary">Login Now</a>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\frontend\emailverified.blade.php ENDPATH**/ ?>