<label class="sidebar-label">Navigation</label>
<div class="sl-sideleft-menu">
  <a href="<?php echo e(url('/home')); ?>" class="sl-menu-link <?php echo $__env->yieldContent('dahboardactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
      <span class="menu-item-label">Dashboard</span>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <a href="<?php echo e(url('/')); ?>" class="sl-menu-link">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-photos-outline tx-20"></i>
      <span class="menu-item-label">Visit Site</span>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <a href="<?php echo e(route('navigationbar')); ?>" class="sl-menu-link <?php echo $__env->yieldContent('navigationactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-paper-outline tx-22"></i>
      <span class="menu-item-label">Navigation bar</span>
      <i class="menu-item-arrow fa fa-angle-down"></i>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->

  <a href="#" class="sl-menu-link <?php echo $__env->yieldContent('categoryactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-paper-outline tx-22"></i>
      <span class="menu-item-label">Category</span>
      <i class="menu-item-arrow fa fa-angle-down"></i>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <ul class="sl-menu-sub nav flex-column">
    <li class="nav-item"><a href="<?php echo e(url('/category')); ?>" class="nav-link">View & Add Category</a></li>

  </ul>
  
  <a href="#" class="sl-menu-link <?php echo $__env->yieldContent('subcategoryactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-paper-outline tx-22"></i>
      <span class="menu-item-label">Subcategory</span>
      <i class="menu-item-arrow fa fa-angle-down"></i>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <ul class="sl-menu-sub nav flex-column">
    <li class="nav-item"><a href="<?php echo e(url('/subcategory')); ?>" class="nav-link">View & Add Subategory</a></li>
  </ul>

  
  <a href="#" class="sl-menu-link <?php echo $__env->yieldContent('color&sizeactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-paper-outline tx-22"></i>
      <span class="menu-item-label">Color & Size</span>
      <i class="menu-item-arrow fa fa-angle-down"></i>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <ul class="sl-menu-sub nav flex-column">
    <li class="nav-item"><a href="<?php echo e(url('/color_size')); ?>" class="nav-link">Add Color & Size</a></li>
  </ul>

  
  <a href="#" class="sl-menu-link <?php echo $__env->yieldContent('productactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-paper-outline tx-22"></i>
      <span class="menu-item-label">Product</span>
      <i class="menu-item-arrow fa fa-angle-down"></i>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <ul class="sl-menu-sub nav flex-column">
    <li class="nav-item"><a href="<?php echo e(route('add.product')); ?>" class="nav-link">View & Add Product</a></li>

  </ul>
  
  <a href="#" class="sl-menu-link <?php echo $__env->yieldContent('couponactive'); ?>">
    <div class="sl-menu-item">
      <i class="menu-item-icon icon ion-ios-paper-outline tx-22"></i>
      <span class="menu-item-label">Coupon</span>
      <i class="menu-item-arrow fa fa-angle-down"></i>
    </div><!-- menu-item -->
  </a><!-- sl-menu-link -->
  <ul class="sl-menu-sub nav flex-column">
    <li class="nav-item"><a href="<?php echo e(route('coupon')); ?>" class="nav-link">Coupon Add & view</a></li>

  </ul>

</div><!-- sl-sideleft-menu -->
<?php /**PATH F:\laravel\covid\resources\views\layouts\adminPartial\sideleftmenu.blade.php ENDPATH**/ ?>