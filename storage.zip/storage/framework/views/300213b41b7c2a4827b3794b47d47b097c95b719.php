<?php $__env->startSection('subcategoryactive'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Covid-Subcategory
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- ########## START: MAIN PANEL ########## -->
<div class="sl-mainpanel">
    <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>">Dashboard</a>
        <span class="breadcrumb-item active">Subcategory</span>
    </nav>

    <div class="sl-pagebody">
        <section>
            <div class="">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header" style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;">
                                <div class="card-title">
                                    <h2 style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Subcategory Information</h2>
                                </div>
                            </div>
                            <?php if(session('delete')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('delete')); ?>

                                </div>

                            <?php endif; ?>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Sl</th>
                                        <th scope="col">Category Name</th>
                                        <th scope="col">Sub Category Name</th>
                                        <th scope="col">Created At</th>
                                        <th scope="col">Updated At</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                                            <td> <?php if(App\Models\category::find($subcategory->category_id)): ?><?php echo e(App\Models\category::find($subcategory->category_id)->category_name); ?>

                                            <?php else: ?>
                                            <?php echo e('uncategorized'); ?>


                                            <?php endif; ?></td>
                                            <td><?php echo e($subcategory->subcategory_name); ?></td>
                                            <td><?php echo e($subcategory->created_at); ?></td>
                                            <td><?php echo e($subcategory->updated_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('/subcategory/edit')); ?>/<?php echo e($subcategory->id); ?>" class="btn btn-warning">Edit</a>
                                                <a href="<?php echo e(url('/subcategory/delete')); ?>/<?php echo e($subcategory->id); ?>" style="background-color: #fb5d5d; color:white" class="btn">Delete</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-header" style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;">
                                <div class="card-title">
                                    <h2 style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Add Subcategory</h2>
                                </div>
                            </div>
                            <?php if(session('insert')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('insert')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(session('subnameexist')): ?>
                            <div class="alert alert-warning">
                                <?php echo e(session('subnameexist')); ?>

                            </div>
                        <?php endif; ?>
                            <div class="card-body">
                                <form action="<?php echo e(route('sub_category_insert')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <select name="category_id" id="" class="form-control form-label">
                                            <option value="">--Select Category--</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-warning">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="">Sub Category Name</label>
                                        <input type="text" name="subcategory_name" class="form-control">
                                        <?php $__errorArgs = ['subcategory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-warning">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group text-center mt-3">
                                        <button style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;" class="btn text-center" type="submit">Add Sub Category</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header" style="text-transform: uppercase; letter-spacing: 2px; background-color: #fb5d5d; color: white;">
                                <div class="card-title">
                                    <h1 style="text-transform: uppercase; letter-spacing: 2px; color: white; text-align: center;">
                                        Trashed Subcategory Information</h1>
                                </div>
                            </div>
                            <?php if(session('delete')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('delete')); ?>

                                </div>

                            <?php endif; ?>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Sl</th>
                                        <th scope="col">Category Name</th>
                                        <th scope="col">Sub Category Name</th>
                                        <th scope="col">Created At</th>
                                        <th scope="col">Updated At</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $subtrashed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trashedsubcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->index+1); ?></th>
                                            <td>
                                            <?php if(App\Models\category::find($trashedsubcategory->category_id)): ?>
                                            <?php echo e(App\Models\category::find($trashedsubcategory->category_id)->category_name); ?>

                                            <?php else: ?>
                                             <?php echo e(('uncategorized')); ?>


                                            <?php endif; ?>
                                        </td>
                                            <td><?php echo e($trashedsubcategory->subcategory_name); ?></td>
                                            <td><?php echo e($trashedsubcategory->created_at); ?></td>
                                            <td><?php echo e($trashedsubcategory->updated_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('/subcategory/restore')); ?>/<?php echo e($trashedsubcategory->id); ?>" class="btn btn-warning">Restore</a>
                                                <a href="<?php echo e(url('/subcategory/permanent_delete')); ?>/<?php echo e($trashedsubcategory->id); ?>" style="background-color: #fb5d5d; color:white" class="btn">Delete</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\covid\resources\views\admin\subcategory\index.blade.php ENDPATH**/ ?>